import pyaudio
import numpy as np
import whisper
import soundfile as sf
import tempfile
import os
import torch
import torchaudio

# Load the Whisper model
model = whisper.load_model("base")

# Load Silero VAD model
model_vad, utils_vad = torch.hub.load(repo_or_dir='snakers4/silero-vad', model='silero_vad', trust_repo=True)
(get_speech_ts, _, _, _, _) = utils_vad

# Parameters for audio capture
FORMAT = pyaudio.paInt16  # Audio format
CHANNELS = 1  # Number of audio channels
RATE = 16000  # Sample rate
CHUNK = 1024  # Buffer size

# Initialize PyAudio
audio = pyaudio.PyAudio()

# Open a stream for audio input
stream = audio.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK)

print("Listening...")

def is_speech(audio_chunk):
    audio_chunk = torch.tensor(audio_chunk, dtype=torch.float32).unsqueeze(0)
    speech_timestamps = get_speech_ts(audio_chunk, model_vad, threshold=0.5)
    return len(speech_timestamps) > 0

try:
    accumulated_audio = []
    silence_threshold = 30  # Number of chunks of silence before considering speech has stopped
    silence_count = 0
    while True:
        # Read audio data from the stream
        audio_data = stream.read(CHUNK)
        
        # Convert audio data to numpy array
        audio_np = np.frombuffer(audio_data, dtype=np.int16).astype(np.float32) / 32768.0
        
        # Check if the chunk contains speech
        if is_speech(audio_np):
            silence_count = 0
            # Accumulate audio data if speech is detected
            accumulated_audio.append(audio_np)
        else:
            silence_count += 1
            # If silence has been detected for a while, process the accumulated audio
            if silence_count > silence_threshold and accumulated_audio:
                # Concatenate accumulated audio
                accumulated_audio = np.concatenate(accumulated_audio)

                # Save accumulated audio to a temporary file
                with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_file:
                    sf.write(temp_file, accumulated_audio, RATE)
                    temp_file_path = temp_file.name

                # Transcribe the audio file
                result = model.transcribe(temp_file_path)
                print(f'Transcription: {result["text"]}')

                # Delete the temporary file
                os.remove(temp_file_path)

                # Reset accumulated audio
                accumulated_audio = []

except KeyboardInterrupt:
    print("Stopping...")
finally:
    # Stop and close the audio stream
    stream.stop_stream()
    stream.close()
    audio.terminate()

from flask import Flask, render_template, jsonify, request
from pymongo import MongoClient
from bson import ObjectId
import pygame
from cryptography.fernet import Fernet
import base64

app = Flask(__name__)
client = MongoClient("mongodb+srv://Admin:Admin123@cluster0.jdc2oyy.mongodb.net/")
db = client.alerts_db
collection = db.alerts

# Connect to the 'noor' database and 'conversations' collection
noor_db = client.noorgabre
conversations_collection = noor_db.conversations
collection_key = noor_db["userdata"]
document_with_key = collection_key.find_one({"key": {"$exists": True}})
key_data = document_with_key["key"]
key_u = key_data
# Initialize pygame
def decrypt_data(encrypted_text, key):
    # Ensure the key is in bytes format
    if isinstance(key, str):
        key = key.encode()  # Convert string to bytes

    f = Fernet(key)
    
    # Decode the base64-encoded encrypted_text
    encrypted_text = base64.urlsafe_b64decode(encrypted_text.encode())

    decrypted = f.decrypt(encrypted_text)
    return decrypted.decode()  # Decode bytes to string
pygame.init()
pygame.mixer.init()

# Global variable to store the previous number of alerts
previous_alerts_count = 0

def get_alerts_and_play_sound():
    global previous_alerts_count
    alerts = list(collection.find())
    # Convert ObjectId fields to strings
    for alert in alerts:
        alert['_id'] = str(alert['_id'])
        alert['chat_id'] = str(alert['chat_id'])  # Use chat_id field instead of _id
    
    # Check if there are new alerts compared to the previous fetch
    current_alerts_count = len(alerts)
    if current_alerts_count > previous_alerts_count:
        for alert in alerts:
            if alert.get('state') != 'done':
                play_sound('static/sound-3.mp3')
                break
    previous_alerts_count = current_alerts_count

    return jsonify({'alerts': alerts})
def get_alerts_id():
    global previous_alerts_count
    alerts = list(collection.find())
    # Convert ObjectId fields to strings
    for alert in alerts:
        alert['_id'] = str(alert['_id'])
        alert['chat_id'] = str(alert['chat_id'])  # Use chat_id field instead of _id
    
    # Check if there are new alerts compared to the previous fetch
    current_alerts_count = len(alerts)
    if current_alerts_count > previous_alerts_count:
        for alert in alerts:
            if alert.get('state') != 'done':
                play_sound('static/sound-3.mp3')
                break
    previous_alerts_count = current_alerts_count

    return {'alerts': alerts}
def get_alert_by_id(alert_id):
    return collection.find_one({'_id': ObjectId(alert_id)})

def get_conversation_by_chat_id(chat_id):
    return conversations_collection.find_one({'_id': ObjectId(chat_id)})

@app.route('/get_location')
def get_location():
    user_id = request.args.get('user_id')
    user_location = collection.find_one({'user_id': user_id}, {'latitude': 1, 'longitude': 1, '_id': 0})
    return jsonify(user_location)

def play_sound(file_path):
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_alerts')
def get_alerts():
    return get_alerts_and_play_sound()

@app.route('/mark_done', methods=['POST'])
def mark_done():
    alert_id = request.json.get('alert_id')
    print(alert_id)
    if alert_id:
        # Update the alert state to "done" in the MongoDB collection
        result = collection.update_one({'_id': ObjectId(alert_id)}, {'$set': {'state': 'done'}})
        if result.modified_count:
            return jsonify({'message': 'Alert marked as done successfully'}), 200
        else:
            error_message = 'Alert not found or already marked as done'
            print(error_message)  # Print the error message
            return jsonify({'message': error_message}), 404
    else:
        error_message = 'Alert ID not provided'
        print(error_message)  # Print the error message
        return jsonify({'message': error_message}), 400



@app.route('/get_conversation_by_chat_id/<chat_id>')
def get_conversation_by_chat_id_route(chat_id):
   

    alerts = get_alerts_id()
    for alert in alerts['alerts']:
        if alert['chat_id'] == str(chat_id):  # Convert ObjectId to string for comparison
            w_u = alert['user_name']
    noor_db = client[w_u]
    conversations_collection = noor_db.conversations
    conversation = conversations_collection.find_one({'_id': ObjectId(chat_id)})
    if conversation:
        # Convert ObjectId to string for JSON serialization
        conversation['_id'] = str(conversation['_id'])
        bot_responses = [decrypt_data(response, key_u) for response in conversation.get('bot_response', [])]
        user_inputs = [decrypt_data(input_text, key_u) for input_text in conversation.get('user_input', [])]
        conversation["user_input"] = user_inputs
        conversation["bot_response"] = bot_responses
        return jsonify(conversation)
    else:
        return jsonify({'error': 'Conversation not found for the given chat_id'}), 404

if __name__ == '__main__':
    app.run(port=5001)
